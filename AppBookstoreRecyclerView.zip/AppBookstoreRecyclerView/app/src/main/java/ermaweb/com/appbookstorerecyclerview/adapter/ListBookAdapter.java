package ermaweb.com.appbookstorerecyclerview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import ermaweb.com.appbookstorerecyclerview.R;
import ermaweb.com.appbookstorerecyclerview.model.Book;

public class ListBookAdapter extends RecyclerView.Adapter<ListBookAdapter.ListViewHolder> {
    private final ArrayList<Book> listBook;
    private OnItemClick onItemClick;

    public void setOnItemClick(OnItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    public ListBookAdapter(ArrayList<Book> listBook) {
        this.listBook = listBook;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_book, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        Book book = listBook.get(position);

        Glide.with(holder.itemView.getContext())
                .load(book.getPhoto())
                .apply(new RequestOptions()
                        .override(300, 300))
                .into(holder.imgPhoto);
        holder.title.setText(book.getTitle());
        holder.author.setText(book.getAuthor());
        holder.desc.setText(book.getDescription());
        holder.itemView.setOnClickListener(v -> {
            onItemClick.onItemClick(listBook.get(holder.getAdapterPosition()));
        });
    }

    @Override
    public int getItemCount() {
        return listBook.size();
    }

    public static class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView title, author, desc;
        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.imageBook);
            title = itemView.findViewById(R.id.tvTitle);
            author = itemView.findViewById(R.id.tvAuthor);
            desc = itemView.findViewById(R.id.tvDescription);
        }
    }

    public interface OnItemClick {
        void onItemClick(Book data);
    }
}
