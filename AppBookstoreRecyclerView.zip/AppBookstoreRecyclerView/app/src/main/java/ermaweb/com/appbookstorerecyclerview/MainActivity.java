package ermaweb.com.appbookstorerecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ermaweb.com.appbookstorerecyclerview.adapter.ListBookAdapter;
import ermaweb.com.appbookstorerecyclerview.model.Book;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvBook;
    private final ArrayList<Book> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvBook = findViewById(R.id.rv_book);
        rvBook.setHasFixedSize(true);

        list.addAll(getList());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvBook.setLayoutManager(new LinearLayoutManager(this));
        ListBookAdapter listBookAdapter = new ListBookAdapter(list);
        rvBook.setAdapter(listBookAdapter);

        listBookAdapter.setOnItemClick((data -> {
            showSelectedBook(data);
        }));
    }

    private void showSelectedBook(Book data) {
        Toast.makeText(this, data.getTitle(), Toast.LENGTH_SHORT).show();
    }

    public ArrayList<Book> getList() {
        String[] dataTitle = getResources().getStringArray(R.array.data_title);
        String[] dataAuthor = getResources().getStringArray(R.array.data_author);
        String[] dataDesc = getResources().getStringArray(R.array.data_description);
        String[] dataPhoto = getResources().getStringArray(R.array.data_photo);

        ArrayList<Book> listBook = new ArrayList<>();
        for (int i = 0; i<dataTitle.length; i++){
            Book book = new Book();
            book.setTitle(dataTitle[i]);
            book.setAuthor(dataAuthor[i]);
            book.setDescription(dataDesc[i]);
            book.setPhoto(dataPhoto[i]);

            listBook.add(book);
        }
        return listBook;
    }
}